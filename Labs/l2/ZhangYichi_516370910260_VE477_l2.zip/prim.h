#ifndef PRIM_H
#define PRIM_H
#include "graph.h"
edge *prim(graph *x);
#endif