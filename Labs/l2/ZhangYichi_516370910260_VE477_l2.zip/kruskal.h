#ifndef KRUSKAL_H
#define KRUSKAL_H
#include "graph.h"
#include "ufs.h"
edge *kruskal(graph *x);
#endif